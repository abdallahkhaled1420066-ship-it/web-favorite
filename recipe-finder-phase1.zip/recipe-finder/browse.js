// Browse page behaviour (front-end demo only, no database).
const form = document.getElementById("search-form");
const cards = document.querySelectorAll(".recipe-card");
const noResults = document.getElementById("no-results");
const countText = document.getElementById("result-count");
const nameInput = document.getElementById("recipe-name");
const ingredientInput = document.getElementById("ingredient");
const courseSelect = document.getElementById("course");
const chips = document.querySelectorAll('input[name="chip"]');

function applyFilters() {
  const name = nameInput.value.trim().toLowerCase();
  const ingredient = ingredientInput.value.trim().toLowerCase();
  const chip = document.querySelector('input[name="chip"]:checked').value;
  const course = courseSelect.value || chip;

  let visible = 0;
  cards.forEach(function (card) {
    const matches =
      card.dataset.name.includes(name) &&
      card.dataset.ingredients.includes(ingredient) &&
      (course === "" || card.dataset.course === course);
    card.hidden = !matches;
    if (matches) visible++;
  });

  noResults.hidden = visible !== 0;
  countText.textContent = "Showing " + visible + (visible === 1 ? " recipe" : " recipes");
}

// Keep the dropdown and the quick-filter chips in sync
courseSelect.addEventListener("change", function () {
  chips.forEach(function (c) { c.checked = c.value === courseSelect.value; });
  applyFilters();
});
chips.forEach(function (c) {
  c.addEventListener("change", function () {
    courseSelect.value = c.value;
    applyFilters();
  });
});

form.addEventListener("submit", function (e) {
  e.preventDefault();
  applyFilters();
});
form.addEventListener("reset", function () {
  // Wait for the reset to finish, then show everything again
  setTimeout(applyFilters, 0);
});
document.getElementById("reset-btn").addEventListener("click", function () {
  form.reset();
});

